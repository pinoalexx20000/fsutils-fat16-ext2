#include "fat16.h"
#include <strings.h>
#include <stdlib.h>

typedef struct {
    fat16_dir_entry *entradas;
    int contador;
    int capacidad;
} listaFat;

static int leer_boot_fat16(int fd, fat16_boot_sector *bs)
{
    if (lseek(fd, 0, SEEK_SET) == -1) {
        return 0;
    }

    if (read(fd, bs, sizeof(fat16_boot_sector)) != (ssize_t) sizeof(fat16_boot_sector)) {
        return 0;
    }

    return 1;
}

static void iniciar_lista_fat(listaFat *lista)
{
    lista->contador = 0;
    lista->capacidad = 64;
    lista->entradas = malloc(sizeof(fat16_dir_entry) * lista->capacidad);
}

static void liberar_lista_fat(listaFat *lista)
{
    if (lista->entradas != NULL) {
        free(lista->entradas);
    }

    lista->entradas = NULL;
    lista->contador = 0;
    lista->capacidad = 0;
}

static void anadir_entrada_fat(listaFat *lista, fat16_dir_entry *entrada)
{
    fat16_dir_entry *nuevo;

    if (lista->entradas == NULL) {
        return;
    }

    if (lista->contador >= lista->capacidad) {
        lista->capacidad = lista->capacidad * 2;
        nuevo = realloc(lista->entradas, sizeof(fat16_dir_entry) * lista->capacidad);

        if (nuevo == NULL) {
            return;
        }

        lista->entradas = nuevo;
    }

    lista->entradas[lista->contador] = *entrada;
    lista->contador++;
}

static void quitar_espacios(char *str)
{
    int len;

    len = (int) strlen(str);

    while (len > 0 && str[len - 1] == ' ') {
        str[len - 1] = '\0';
        len--;
    }
}

static void crear_nombre_fat16(fat16_dir_entry *entrada, char *buffer, size_t size)
{
    char nombre[9];
    char extension[4];

    memcpy(nombre, entrada->name, 8);
    nombre[8] = '\0';

    memcpy(extension, entrada->ext, 3);
    extension[3] = '\0';

    quitar_espacios(nombre);
    quitar_espacios(extension);

    if (extension[0] != '\0') {
        snprintf(buffer, size, "%s.%s", nombre, extension);
    } else {
        snprintf(buffer, size, "%s", nombre);
    }
}

static uint32_t calcular_zona_root(fat16_boot_sector *bs)
{
    uint32_t zonaRoot;

    zonaRoot = ((bs->root_entries * sizeof(fat16_dir_entry)) + (bs->bytes_per_sector - 1)) / bs->bytes_per_sector;
    zonaRoot = zonaRoot * bs->bytes_per_sector;

    return zonaRoot;
}

static uint32_t calcular_inicio_datos(fat16_boot_sector *bs)
{
    uint32_t zonaReservada;
    uint32_t zonaFat;
    uint32_t zonaRoot;

    zonaReservada = bs->reserved_sectors * bs->bytes_per_sector;
    zonaFat = bs->fat_count * bs->sectors_per_fat * bs->bytes_per_sector;
    zonaRoot = calcular_zona_root(bs);

    return zonaReservada + zonaFat + zonaRoot;
}

static uint16_t leer_entrada_fat(int fd, fat16_boot_sector *bs, uint16_t cluster)
{
    off_t offset;
    uint16_t valor;

    offset = (off_t) bs->reserved_sectors * bs->bytes_per_sector + (off_t) cluster * 2;

    if (lseek(fd, offset, SEEK_SET) == -1) {
        return 0xFFFF;
    }

    if (read(fd, &valor, sizeof(uint16_t)) != (ssize_t) sizeof(uint16_t)) {
        return 0xFFFF;
    }

    return valor;
}

static int fin_cluster(uint16_t valor)
{
    return (valor >= 0xFFF8);
}

static int cluster_malo(uint16_t valor)
{
    if (valor == 0xFFF7) {
        return 1;
    }

    return 0;
}

static int cluster_valido(uint16_t valor)
{
    if (valor >= 2 && valor < 0xFFF0) {
        return 1;
    }

    return 0;
}

static int entrada_valida_para_tree(fat16_dir_entry *entrada)
{
    char nombreCompleto[20];

    if ((unsigned char) entrada->name[0] == 0x00) {
        return 0;
    }

    if ((unsigned char) entrada->name[0] == 0xE5) {
        return 0;
    }

    if (entrada->attr == 0x0F) {
        return 0;
    }

    if ((entrada->attr & 0x08) != 0) {
        return 0;
    }

    crear_nombre_fat16(entrada, nombreCompleto, sizeof(nombreCompleto));

    if (strcmp(nombreCompleto, ".") == 0 || strcmp(nombreCompleto, "..") == 0) {
        return 0;
    }

    return 1;
}

static void print_tree_prefix(int depth, int is_last, int levels[])
{
    int i;

    for (i = 0; i < depth; i++) {
        if (levels[i]) {
            printf("│   ");
        } else {
            printf("    ");
        }
    }

    if (is_last) {
        printf("└── ");
    } else {
        printf("├── ");
    }
}

static void imprimir_directorio_cluster(int fd, fat16_boot_sector *bs, uint16_t clusterInicial, int depth, int levels[]);

void print_fat16_info(int fd)
{
    fat16_boot_sector bs;
    char sistema[9];
    char etiqueta[12];

    if (!leer_boot_fat16(fd, &bs)) {
        printf("Error: cannot read FAT16 boot sector\n");
        return;
    }

    memcpy(sistema, bs.oem_name, 8);
    sistema[8] = '\0';
    quitar_espacios(sistema);

    memcpy(etiqueta, bs.volume_label, 11);
    etiqueta[11] = '\0';
    quitar_espacios(etiqueta);

    printf("------ Filesystem Information ------\n\n");
    printf("Filesystem: FAT16\n\n");
    printf("System name: %s\n", sistema);
    printf("Sector size: %u\n", bs.bytes_per_sector);
    printf("Sectors per cluster: %u\n", bs.sectors_per_cluster);
    printf("Reserved sectors: %u\n", bs.reserved_sectors);
    printf("# of FATs: %u\n", bs.fat_count);
    printf("Max root entries: %u\n", bs.root_entries);
    printf("Sectors per FAT: %u\n", bs.sectors_per_fat);
    printf("Label: %s\n", etiqueta);
}

static void imprimir_root_fat16(int fd, fat16_boot_sector *bs, int depth, int levels[])
{
    uint32_t zonaReservada;
    uint32_t zonaFat;
    uint32_t offsetRoot;
    uint32_t numEntradas;
    uint32_t i;
    fat16_dir_entry entrada;
    listaFat lista;

    zonaReservada = bs->reserved_sectors * bs->bytes_per_sector;
    zonaFat = bs->fat_count * bs->sectors_per_fat * bs->bytes_per_sector;
    offsetRoot = zonaReservada + zonaFat;
    numEntradas = bs->root_entries;

    if (lseek(fd, offsetRoot, SEEK_SET) == -1) {
        printf("Error: cannot read FAT16 root directory\n");
        return;
    }

    iniciar_lista_fat(&lista);

    if (lista.entradas == NULL) {
        return;
    }

    for (i = 0; i < numEntradas; i++) {
        if (read(fd, &entrada, sizeof(fat16_dir_entry)) != (ssize_t) sizeof(fat16_dir_entry)) {
            printf("Error: cannot read FAT16 root directory\n");
            liberar_lista_fat(&lista);
            return;
        }

        if ((unsigned char) entrada.name[0] == 0x00) {
            break;
        }

        if (entrada_valida_para_tree(&entrada)) {
            anadir_entrada_fat(&lista, &entrada);
        }
    }

    for (i = 0; i < (uint32_t) lista.contador; i++) {
        char nombreCompleto[20];
        uint16_t primerCluster;
        int esUltimo;

        crear_nombre_fat16(&lista.entradas[i], nombreCompleto, sizeof(nombreCompleto));

        esUltimo = (i == (uint32_t) lista.contador - 1);

        print_tree_prefix(depth, esUltimo, levels);
        printf("%s\n", nombreCompleto);

        primerCluster = lista.entradas[i].first_cluster_low;

        if ((lista.entradas[i].attr & 0x10) != 0 && cluster_valido(primerCluster)) {
            levels[depth] = !esUltimo;
            imprimir_directorio_cluster(fd, bs, primerCluster, depth + 1, levels);
        }
    }

    liberar_lista_fat(&lista);
}

static void imprimir_directorio_cluster(int fd, fat16_boot_sector *bs, uint16_t clusterInicial, int depth, int levels[])
{
    uint16_t clusterActual;
    uint32_t tamCluster;
    uint32_t inicioDatos;
    char *buffer;
    listaFat lista;
    int parar;

    clusterActual = clusterInicial;
    tamCluster = bs->bytes_per_sector * bs->sectors_per_cluster;
    inicioDatos = calcular_inicio_datos(bs);

    buffer = malloc(tamCluster);

    if (buffer == NULL) {
        return;
    }

    iniciar_lista_fat(&lista);

    if (lista.entradas == NULL) {
        free(buffer);
        return;
    }

    parar = 0;

    while (cluster_valido(clusterActual) && !parar) {
        off_t offsetCluster;
        uint32_t totalEntradas;
        uint32_t i;

        offsetCluster = inicioDatos + (off_t)(clusterActual - 2) * tamCluster;

        if (lseek(fd, offsetCluster, SEEK_SET) == -1) {
            break;
        }

        if (read(fd, buffer, tamCluster) != (ssize_t) tamCluster) {
            break;
        }

        totalEntradas = tamCluster / sizeof(fat16_dir_entry);

        for (i = 0; i < totalEntradas; i++) {
            fat16_dir_entry *entrada;

            entrada = (fat16_dir_entry *)(buffer + i * sizeof(fat16_dir_entry));

            if ((unsigned char) entrada->name[0] == 0x00) {
                parar = 1;
                break;
            }

            if (entrada_valida_para_tree(entrada)) {
                anadir_entrada_fat(&lista, entrada);
            }
        }

        if (!parar) {
            clusterActual = leer_entrada_fat(fd, bs, clusterActual);

            if (fin_cluster(clusterActual)) {
                break;
            }

            if (cluster_malo(clusterActual)) {
                break;
            }
        }
    }

    for (uint32_t i = 0; i < (uint32_t) lista.contador; i++) {
        char nombreCompleto[20];
        uint16_t primerCluster;
        int esUltimo;

        crear_nombre_fat16(&lista.entradas[i], nombreCompleto, sizeof(nombreCompleto));

        esUltimo = (i == (uint32_t) lista.contador - 1);

        print_tree_prefix(depth, esUltimo, levels);
        printf("%s\n", nombreCompleto);

        primerCluster = lista.entradas[i].first_cluster_low;

        if ((lista.entradas[i].attr & 0x10) != 0 && cluster_valido(primerCluster)) {
            levels[depth] = !esUltimo;
            imprimir_directorio_cluster(fd, bs, primerCluster, depth + 1, levels);
        }
    }

    liberar_lista_fat(&lista);
    free(buffer);
}

static void mostrar_contenido_archivo(int fd, fat16_boot_sector *bs, uint16_t primerCluster, uint32_t tamArchivo)
{
    uint16_t clusterActual;
    uint32_t tamCluster;
    uint32_t inicioDatos;
    uint32_t bytesRestantes;
    char *buffer;

    clusterActual = primerCluster;
    tamCluster = bs->bytes_per_sector * bs->sectors_per_cluster;
    inicioDatos = calcular_inicio_datos(bs);

    buffer = malloc(tamCluster);

    if (buffer == NULL) {
        return;
    }

    bytesRestantes = tamArchivo;

    while (cluster_valido(clusterActual) && bytesRestantes > 0) {
        off_t offsetCluster;
        uint32_t bytesLeer;

        offsetCluster = inicioDatos + (off_t)(clusterActual - 2) * tamCluster;

        if (lseek(fd, offsetCluster, SEEK_SET) == -1) {
            free(buffer);
            return;
        }

        if (read(fd, buffer, tamCluster) != (ssize_t) tamCluster) {
            free(buffer);
            return;
        }

        if (bytesRestantes < tamCluster) {
            bytesLeer = bytesRestantes;
        } else {
            bytesLeer = tamCluster;
        }

        write(1, buffer, bytesLeer);

        bytesRestantes = bytesRestantes - bytesLeer;
        clusterActual = leer_entrada_fat(fd, bs, clusterActual);

        if (fin_cluster(clusterActual) || cluster_malo(clusterActual)) {
            break;
        }
    }

    free(buffer);
}

static int buscar_en_root(int fd, fat16_boot_sector *bs, char *nombreBuscado, fat16_dir_entry *resultado)
{
    uint32_t zonaReservada;
    uint32_t zonaFat;
    uint32_t offsetRoot;
    uint32_t numEntradas;
    uint32_t i;
    fat16_dir_entry entrada;

    zonaReservada = bs->reserved_sectors * bs->bytes_per_sector;
    zonaFat = bs->fat_count * bs->sectors_per_fat * bs->bytes_per_sector;
    offsetRoot = zonaReservada + zonaFat;
    numEntradas = bs->root_entries;

    if (lseek(fd, offsetRoot, SEEK_SET) == -1) {
        return 0;
    }

    for (i = 0; i < numEntradas; i++) {
        char nombreCompleto[20];

        if (read(fd, &entrada, sizeof(fat16_dir_entry)) != (ssize_t) sizeof(fat16_dir_entry)) {
            return 0;
        }

        if ((unsigned char) entrada.name[0] == 0x00) {
            break;
        }

        if ((unsigned char) entrada.name[0] == 0xE5) continue;
        if (entrada.attr == 0x0F) continue;
        if ((entrada.attr & 0x08) != 0) continue;

        crear_nombre_fat16(&entrada, nombreCompleto, sizeof(nombreCompleto));

        if (strcasecmp(nombreCompleto, nombreBuscado) == 0) {
            *resultado = entrada;
            return 1;
        }
    }

    return 0;
}

static int buscar_en_cluster(int fd, fat16_boot_sector *bs, uint16_t clusterInicial, char *nombreBuscado, fat16_dir_entry *resultado)
{
    uint16_t clusterActual;
    uint32_t tamCluster;
    uint32_t inicioDatos;
    char *buffer;

    clusterActual = clusterInicial;
    tamCluster = bs->bytes_per_sector * bs->sectors_per_cluster;
    inicioDatos = calcular_inicio_datos(bs);

    buffer = malloc(tamCluster);

    if (buffer == NULL) {
        return 0;
    }

    while (cluster_valido(clusterActual)) {
        off_t offsetCluster;
        uint32_t totalEntradas;
        uint32_t i;

        offsetCluster = inicioDatos + (off_t)(clusterActual - 2) * tamCluster;

        if (lseek(fd, offsetCluster, SEEK_SET) == -1) {
            free(buffer);
            return 0;
        }

        if (read(fd, buffer, tamCluster) != (ssize_t) tamCluster) {
            free(buffer);
            return 0;
        }

        totalEntradas = tamCluster / sizeof(fat16_dir_entry);

        for (i = 0; i < totalEntradas; i++) {
            fat16_dir_entry *entrada;
            char nombreCompleto[20];

            entrada = (fat16_dir_entry *)(buffer + i * sizeof(fat16_dir_entry));

            if ((unsigned char) entrada->name[0] == 0x00) {
                free(buffer);
                return 0;
            }

            if ((unsigned char) entrada->name[0] == 0xE5) continue;
            if (entrada->attr == 0x0F) continue;
            if ((entrada->attr & 0x08) != 0) continue;

            crear_nombre_fat16(entrada, nombreCompleto, sizeof(nombreCompleto));

            if (strcasecmp(nombreCompleto, nombreBuscado) == 0) {
                *resultado = *entrada;
                free(buffer);
                return 1;
            }
        }

        clusterActual = leer_entrada_fat(fd, bs, clusterActual);

        if (fin_cluster(clusterActual) || cluster_malo(clusterActual)) {
            break;
        }
    }

    free(buffer);
    return 0;
}

void print_fat16_cat(int fd, char *nombreArchivo)
{
    fat16_boot_sector bs;
    fat16_dir_entry entrada;
    fat16_dir_entry carpeta;
    char ruta[256];
    char *parte;
    char *siguiente;
    uint16_t clusterActual;
    int estoyEnRoot;

    if (!leer_boot_fat16(fd, &bs)) {
        printf("Error: cannot read FAT16 boot sector\n");
        return;
    }

    strncpy(ruta, nombreArchivo, sizeof(ruta) - 1);
    ruta[sizeof(ruta) - 1] = '\0';

    parte = strtok(ruta, "/");
    if (parte == NULL) {
        printf("Error: file not found\n");
        return;
    }

    estoyEnRoot = 1;
    clusterActual = 0;

    while (parte != NULL) {
        siguiente = strtok(NULL, "/");

        if (estoyEnRoot) {
            if (!buscar_en_root(fd, &bs, parte, &entrada)) {
                printf("Error: file not found\n");
                return;
            }
        } else {
            if (!buscar_en_cluster(fd, &bs, clusterActual, parte, &entrada)) {
                printf("Error: file not found\n");
                return;
            }
        }

        if (siguiente == NULL) {
            if ((entrada.attr & 0x10) != 0) {
                printf("Error: it is a directory\n");
                return;
            }

            mostrar_contenido_archivo(fd, &bs, entrada.first_cluster_low, entrada.file_size);
            return;
        }

        if ((entrada.attr & 0x10) == 0) {
            printf("Error: file not found\n");
            return;
        }

        carpeta = entrada;
        clusterActual = carpeta.first_cluster_low;
        estoyEnRoot = 0;

        parte = siguiente;
    }

    printf("Error: file not found\n");
}

int is_fat16(int fd)
{
    fat16_boot_sector bs;
    uint32_t sectoresRoot;
    uint32_t sectoresTotales;
    uint32_t sectoresDatos;
    uint32_t numClusters;

    if (!leer_boot_fat16(fd, &bs)) {
        return 0;
    }

    if (bs.bytes_per_sector != 512 &&
        bs.bytes_per_sector != 1024 &&
        bs.bytes_per_sector != 2048 &&
        bs.bytes_per_sector != 4096) {
        return 0;
    }

    if (bs.sectors_per_cluster == 0) {
        return 0;
    }

    if (bs.reserved_sectors == 0) {
        return 0;
    }

    if (bs.fat_count == 0) {
        return 0;
    }

    if (bs.root_entries == 0) {
        return 0;
    }

    if (bs.sectors_per_fat == 0) {
        return 0;
    }

    if (bs.total_sectors_16 != 0) {
        sectoresTotales = bs.total_sectors_16;
    } else {
        sectoresTotales = bs.total_sectors_32;
    }

    if (sectoresTotales == 0) {
        return 0;
    }

    sectoresRoot = ((bs.root_entries * 32) + (bs.bytes_per_sector - 1)) / bs.bytes_per_sector;

    if (sectoresTotales <= bs.reserved_sectors + (bs.fat_count * bs.sectors_per_fat) + sectoresRoot) {
        return 0;
    }

    sectoresDatos = sectoresTotales - (bs.reserved_sectors + (bs.fat_count * bs.sectors_per_fat) + sectoresRoot);
    numClusters = sectoresDatos / bs.sectors_per_cluster;

    if (numClusters >= 4085 && numClusters < 65525) {
        return 1;
    }

    return 0;
}

void print_fat16_tree(int fd)
{
    fat16_boot_sector bs;
    int levels[64] = {0};

    if (!leer_boot_fat16(fd, &bs)) {
        printf("Error: cannot read FAT16 boot sector\n");
        return;
    }

    imprimir_root_fat16(fd, &bs, 0, levels);
}