#include "fs.h"
#include "ext2.h"
#include "fat16.h"

int main(int argc, char *argv[])
{
    int fd;

    if (argc != 3 && argc != 4) {
        printf("Usage: ./fsutils --info <file_system>\n");
        printf("Usage: ./fsutils --tree <file_system>\n");
        printf("Usage: ./fsutils --cat <FAT16 file_system> <file>\n");
        return FS_ERROR;
    }

    fd = open(argv[2], O_RDONLY);
    if (fd < 0) {
        printf("Error: cannot open file system\n");
        return FS_ERROR;
    }

    if (strcmp(argv[1], "--info") == 0) {
        if (argc != 3) {
            printf("Usage: ./fsutils --info <file_system>\n");
            close(fd);
            return FS_ERROR;
        }

        if (is_ext2(fd)) {
            print_ext2_info(fd);
        } else if (is_fat16(fd)) {
            print_fat16_info(fd);
        } else {
            printf("Error: unsupported file system\n");
            close(fd);
            return FS_ERROR;
        }
    }
    else if (strcmp(argv[1], "--tree") == 0) {
        if (argc != 3) {
            printf("Usage: ./fsutils --tree <file_system>\n");
            close(fd);
            return FS_ERROR;
        }

        if (is_ext2(fd)) {
            print_ext2_tree(fd);
        } else if (is_fat16(fd)) {
            print_fat16_tree(fd);
        } else {
            printf("Error: unsupported file system\n");
            close(fd);
            return FS_ERROR;
        }
    }
    else if (strcmp(argv[1], "--cat") == 0) {
        if (argc != 4) {
            printf("Usage: ./fsutils --cat <FAT16 file_system> <file>\n");
            close(fd);
            return FS_ERROR;
        }

        if (is_fat16(fd)) {
            print_fat16_cat(fd, argv[3]);
        } else {
            printf("Error: unsupported file system\n");
            close(fd);
            return FS_ERROR;
        }
    }
    else {
        printf("Error: invalid option\n");
        close(fd);
        return FS_ERROR;
    }

    close(fd);
    return FS_OK;
}