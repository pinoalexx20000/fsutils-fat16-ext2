#include "ext2.h"
#include <stdlib.h>

typedef struct {
    uint32_t inode;
    char nombre[256];
} entradaValida;

typedef struct {
    entradaValida *entradas;
    int contador;
    int capacidad;
} listaEntradas;

static void iniciar_lista(listaEntradas *lista)
{
    lista->contador = 0;
    lista->capacidad = 64;
    lista->entradas = malloc(sizeof(entradaValida) * lista->capacidad);
}

static void liberar_lista(listaEntradas *lista)
{
    if (lista->entradas != NULL) {
        free(lista->entradas);
    }

    lista->entradas = NULL;
    lista->contador = 0;
    lista->capacidad = 0;
}

static void anadir_entrada(listaEntradas *lista, uint32_t inode, const char *nombre)
{
    entradaValida *nuevo;

    if (lista->entradas == NULL) {
        return;
    }

    if (lista->contador >= lista->capacidad) {
        lista->capacidad = lista->capacidad * 2;
        nuevo = realloc(lista->entradas, sizeof(entradaValida) * lista->capacidad);

        if (nuevo == NULL) {
            return;
        }

        lista->entradas = nuevo;
    }

    lista->entradas[lista->contador].inode = inode;
    strncpy(lista->entradas[lista->contador].nombre, nombre, 255);
    lista->entradas[lista->contador].nombre[255] = '\0';
    lista->contador++;
}

static void format_time(uint32_t raw_time, char *buffer, size_t size)
{
    time_t t;
    struct tm *infoTiempo;

    t = (time_t) raw_time;
    infoTiempo = localtime(&t);

    if (infoTiempo == NULL) {
        snprintf(buffer, size, "Unknown");
        return;
    }

    strftime(buffer, size, "%a %b %d %H:%M:%S %Y", infoTiempo);
}

int is_ext2(int fd)
{
    uint16_t magic;

    if (lseek(fd, 1024 + 56, SEEK_SET) == -1) {
        return 0;
    }

    if (read(fd, &magic, sizeof(magic)) != (ssize_t) sizeof(magic)) {
        return 0;
    }

    if (magic == 0xEF53) {
        return 1;
    }

    return 0;
}

void print_ext2_info(int fd)
{
    ext2_superblock sb;
    uint32_t tamBloque;
    char nombreVolumen[17];
    char ultimaRevision[40];
    char ultimoMontaje[40];
    char ultimaEscritura[40];

    if (lseek(fd, 1024, SEEK_SET) == -1) {
        printf("Error: cannot read EXT2 superblock\n");
        return;
    }

    if (read(fd, &sb, sizeof(ext2_superblock)) != (ssize_t) sizeof(ext2_superblock)) {
        printf("Error: cannot read EXT2 superblock\n");
        return;
    }

    tamBloque = 1024 << sb.s_log_block_size;

    memcpy(nombreVolumen, sb.s_volume_name, 16);
    nombreVolumen[16] = '\0';

    format_time(sb.s_lastcheck, ultimaRevision, sizeof(ultimaRevision));
    format_time(sb.s_mtime, ultimoMontaje, sizeof(ultimoMontaje));
    format_time(sb.s_wtime, ultimaEscritura, sizeof(ultimaEscritura));

    printf("------ Filesystem Information ------\n\n");
    printf("Filesystem: EXT2\n\n");

    printf("INODE INFO\n");
    printf("  Size: %u\n", sb.s_inode_size);
    printf("  Num Inodes: %u\n", sb.s_inodes_count);
    printf("  First Inode: %u\n", sb.s_first_ino);
    printf("  Inodes per group: %u\n", sb.s_inodes_per_group);
    printf("  Free Inodes: %u\n\n", sb.s_free_inodes_count);

    printf("BLOCK INFO\n");
    printf("  Block size: %u\n", tamBloque);
    printf("  Reserved blocks: %u\n", sb.s_r_blocks_count);
    printf("  Free blocks: %u\n", sb.s_free_blocks_count);
    printf("  Total blocks: %u\n", sb.s_blocks_count);
    printf("  First block: %u\n", sb.s_first_data_block);
    printf("  Blocks per group: %u\n", sb.s_blocks_per_group);
    printf("  Frags per group: %u\n\n", sb.s_frags_per_group);

    printf("VOLUME INFO\n");
    printf("  Volume name: %s\n", nombreVolumen);
    printf("  Last checked: %s\n", ultimaRevision);
    printf("  Last mounted: %s\n", ultimoMontaje);
    printf("  Last written: %s\n", ultimaEscritura);
}

static void print_tree_prefix(int depth, int is_last, int levels[])
{
    int i;

    for (i = 0; i < depth; i++) {
        if (levels[i]) {
            printf("│   ");
        } else {
            printf("    ");
        }
    }

    if (is_last) {
        printf("└── ");
    } else {
        printf("├── ");
    }
}

static int read_ext2_superblock(int fd, ext2_superblock *sb)
{
    if (lseek(fd, 1024, SEEK_SET) == -1) {
        return 0;
    }

    if (read(fd, sb, sizeof(ext2_superblock)) != (ssize_t) sizeof(ext2_superblock)) {
        return 0;
    }

    return 1;
}

static int read_ext2_group_desc(int fd, const ext2_superblock *sb, ext2_group_desc *gd, uint32_t grupo)
{
    off_t offsetTabla;
    uint32_t tamBloque;

    tamBloque = 1024 << sb->s_log_block_size;

    if (tamBloque == 1024) {
        offsetTabla = 2048;
    } else {
        offsetTabla = tamBloque;
    }

    offsetTabla = offsetTabla + (off_t) grupo * sizeof(ext2_group_desc);

    if (lseek(fd, offsetTabla, SEEK_SET) == -1) {
        return 0;
    }

    if (read(fd, gd, sizeof(ext2_group_desc)) != (ssize_t) sizeof(ext2_group_desc)) {
        return 0;
    }

    return 1;
}

static int read_ext2_inode(int fd, const ext2_superblock *sb, uint32_t numInodo, ext2_inode *inode)
{
    ext2_group_desc gd;
    uint32_t tamBloque;
    uint32_t grupo;
    uint32_t posicion;
    off_t offsetInodo;

    if (numInodo == 0) {
        return 0;
    }

    tamBloque = 1024 << sb->s_log_block_size;
    grupo = (numInodo - 1) / sb->s_inodes_per_group;
    posicion = (numInodo - 1) % sb->s_inodes_per_group;

    if (!read_ext2_group_desc(fd, sb, &gd, grupo)) {
        return 0;
    }

    offsetInodo = (off_t) gd.bg_inode_table * tamBloque;
    offsetInodo = offsetInodo + (off_t) posicion * sb->s_inode_size;

    if (lseek(fd, offsetInodo, SEEK_SET) == -1) {
        return 0;
    }

    if (read(fd, inode, sizeof(ext2_inode)) != (ssize_t) sizeof(ext2_inode)) {
        return 0;
    }

    return 1;
}

static int is_ext2_directory(const ext2_inode *inode)
{
    if ((inode->i_mode & 0xF000) == 0x4000) {
        return 1;
    }

    return 0;
}

static void leer_entradas_bloque_ext2(int fd, uint32_t numBloque, uint32_t tamBloque, listaEntradas *lista)
{
    off_t offsetBloque;
    uint32_t pos;
    char *bufferBloque;

    if (numBloque == 0) {
        return;
    }

    bufferBloque = malloc(tamBloque);

    if (bufferBloque == NULL) {
        return;
    }

    offsetBloque = (off_t) numBloque * tamBloque;

    if (lseek(fd, offsetBloque, SEEK_SET) == -1) {
        free(bufferBloque);
        return;
    }

    if (read(fd, bufferBloque, tamBloque) != (ssize_t) tamBloque) {
        free(bufferBloque);
        return;
    }

    pos = 0;

    while (pos < tamBloque) {
        ext2_dir_entry *entry;
        char nombre[256];

        entry = (ext2_dir_entry *) (bufferBloque + pos);

        if (entry->rec_len == 0) {
            break;
        }

        if (pos + entry->rec_len > tamBloque) {
            break;
        }

        if (entry->rec_len < 8) {
            break;
        }

        if (entry->inode != 0 && entry->name_len > 0 && entry->name_len < 255) {
            if (entry->name_len <= entry->rec_len - 8) {
                memcpy(nombre, entry->name, entry->name_len);
                nombre[entry->name_len] = '\0';

                if (strcmp(nombre, ".") != 0 && strcmp(nombre, "..") != 0) {
                    anadir_entrada(lista, entry->inode, nombre);
                }
            }
        }

        pos = pos + entry->rec_len;
    }

    free(bufferBloque);
}

static void leer_bloques_indirectos_ext2(int fd, uint32_t numBloque, uint32_t tamBloque, int nivel, listaEntradas *lista)
{
    uint32_t *bloques;
    uint32_t total;
    uint32_t i;
    off_t offsetBloque;

    if (numBloque == 0) {
        return;
    }

    if (nivel <= 0) {
        return;
    }

    bloques = malloc(tamBloque);

    if (bloques == NULL) {
        return;
    }

    offsetBloque = (off_t) numBloque * tamBloque;

    if (lseek(fd, offsetBloque, SEEK_SET) == -1) {
        free(bloques);
        return;
    }

    if (read(fd, bloques, tamBloque) != (ssize_t) tamBloque) {
        free(bloques);
        return;
    }

    total = tamBloque / sizeof(uint32_t);

    for (i = 0; i < total; i++) {
        if (bloques[i] != 0) {
            if (nivel == 1) {
                leer_entradas_bloque_ext2(fd, bloques[i], tamBloque, lista);
            } else {
                leer_bloques_indirectos_ext2(fd, bloques[i], tamBloque, nivel - 1, lista);
            }
        }
    }

    free(bloques);
}

static void leer_entradas_directorio_ext2(int fd, const ext2_superblock *sb, const ext2_inode *inodoDir, listaEntradas *lista)
{
    uint32_t tamBloque;
    int i;

    tamBloque = 1024 << sb->s_log_block_size;

    for (i = 0; i < 12; i++) {
        leer_entradas_bloque_ext2(fd, inodoDir->i_block[i], tamBloque, lista);
    }

    leer_bloques_indirectos_ext2(fd, inodoDir->i_block[12], tamBloque, 1, lista);
    leer_bloques_indirectos_ext2(fd, inodoDir->i_block[13], tamBloque, 2, lista);
    leer_bloques_indirectos_ext2(fd, inodoDir->i_block[14], tamBloque, 3, lista);
}

static void print_ext2_directory(int fd, const ext2_superblock *sb, uint32_t numInodo, int depth, int levels[])
{
    ext2_inode inodoDir;
    listaEntradas lista;
    int i;

    if (!read_ext2_inode(fd, sb, numInodo, &inodoDir)) {
        return;
    }

    if (!is_ext2_directory(&inodoDir)) {
        return;
    }

    iniciar_lista(&lista);

    if (lista.entradas == NULL) {
        return;
    }

    leer_entradas_directorio_ext2(fd, sb, &inodoDir, &lista);

    for (i = 0; i < lista.contador; i++) {
        ext2_inode inodoHijo;
        int esUltimo;

        esUltimo = (i == lista.contador - 1);

        print_tree_prefix(depth, esUltimo, levels);
        printf("%s\n", lista.entradas[i].nombre);

        if (read_ext2_inode(fd, sb, lista.entradas[i].inode, &inodoHijo)) {
            if (is_ext2_directory(&inodoHijo)) {
                levels[depth] = !esUltimo;
                print_ext2_directory(fd, sb, lista.entradas[i].inode, depth + 1, levels);
            }
        }
    }

    liberar_lista(&lista);
}

void print_ext2_tree(int fd)
{
    ext2_superblock sb;
    int levels[64] = {0};

    if (!read_ext2_superblock(fd, &sb)) {
        printf("Error: cannot read EXT2 superblock\n");
        return;
    }

    print_ext2_directory(fd, &sb, 2, 0, levels);
}