## Autor

Grupo 15
Alex O.C.

README - FSUtils

Este proyecto implementa una herramienta en C llamada fsutils.

El programa sirve para leer imágenes de sistemas de ficheros EXT2 y FAT16 sin montarlas en el sistema operativo. Para hacerlo se usan funciones de bajo nivel como open, read, lseek y close.

El programa permite:

- Mostrar información del sistema de ficheros.
- Mostrar el árbol de directorios y archivos.
- Mostrar el contenido de un archivo en FAT16.

## 1. Explicación de la estructura del proyecto

La estructura del proyecto es la siguiente:

GROUP_15_ALEX.OC/
|
|-- include/
| |-- fs.h
| |-- ext2.h
| |-- fat16.h
|
|-- src/
| |-- main.c
| |-- ext2.c
| |-- fat16.c
|
|-- images/
| |-- studentext100MB
| |-- studentfat100MB
| |-- DEVINfat
| |-- D3V1Next
|
|-- Makefile
|-- README.md

En Fs.h contiene los includes generales y constantes simples como FS_OK y FS_ERROR.

El archivo ext2.h contiene las estructuras que se necesitan para leer un sistema EXT2, como el superbloque, los descriptores de grupo, los inodos y las entradas de directorio. El archivo fat16.h hace lo mismo pero para FAT16, con estructuras como el boot sector y las entradas de directorio.

En la carpeta src está el código principal del programa. El archivo main.c se encarga de mirar los argumentos que se pasan por consola y decide qué función se tiene que ejecutar según la opción usada, por ejemplo --info, --tree o --cat.

El archivo ext2.c contiene la parte de EXT2, como detectar si una imagen es EXT2, imprimir su información y recorrer sus directorios y archivos. El archivo fat16.c contiene la parte de FAT16, como detectar si una imagen es FAT16, imprimir información, recorrer directorios y mostrar el contenido de un archivo con --cat.

La carpeta images contiene las imágenes de sistemas de ficheros que se han usado para probar el programa durante el desarrollo.

## 2. Instrucciones de compilación

Para compilar el proyecto, primero hay que situarse en la carpeta principal, es decir, en la carpeta donde se encuentra el Makefile. Antes de compilar, se puede limpiar cualquier compilación anterior con el comando `make clean`. Después, para compilar el proyecto, se ejecuta `make`. Si la compilación se realiza correctamente, se generará el ejecutable del programa llamado fsutils.

Paso 1: - `make clean`
Paso 2: - `make`

## 3. Instrucciones de ejecución

El programa se ejecuta desde la carpeta principal usando esta estructura:

./fsutils <opcion> <imagen> [archivo]

Las opciones disponibles son:

--info
--tree
--cat

### 3.1 Ejecutar --info

La opción --info muestra información básica del sistema de ficheros.

Formato:

./fsutils --info <file_system>

Ejemplo con EXT2:

./fsutils --info images/studentext100MB

Ejemplo con FAT16:

./fsutils --info images/studentfat100MB

En EXT2 se muestra información sobre inodos, bloques y volumen.

En FAT16 se muestra información como el tamaño de sector, sectores por cluster, número de FATs, entradas máximas del root directory, sectores por FAT y etiqueta del volumen.

### 3.2 Ejecutar --tree

La opción --tree muestra los directorios y archivos del sistema de ficheros en forma de árbol.

Formato:

./fsutils --tree <file_system>

Ejemplo con EXT2:

./fsutils --tree images/studentext100MB

Ejemplo con FAT16:

./fsutils --tree images/studentfat100MB

La salida tiene un formato parecido al comando tree, por ejemplo:

├── ASO
| ├──shopping_list.txt
| ├── pipes.sh
├── donut
| ├── donut.c
| └── .donete
| └── donete_pro.c
└── SO
└── practica.c

En FAT16 los nombres pueden aparecer en formato corto 8.3, por ejemplo:

SHOPPI~1.TXT
ITERAT~1.C
RECURS~1.C

Esto es normal porque en el enunciado se indica que no hace falta recuperar los nombres largos LFN.

### 3.3 Ejecutar --cat

La opción --cat muestra el contenido de un archivo dentro de una imagen FAT16.

Formato:

./fsutils --cat <FAT16 file_system> <file>

Ejemplo:

./fsutils --cat images/DEVINfat COMPUS/EXTRA/TODOLIST.TXT

También funciona usando minúsculas:

./fsutils --cat images/DEVINfat compus/extra/todolist.txt

Si el archivo no existe, se muestra un mensaje de error.

## 4. Explicación básica del funcionamiento

### 4.1 EXT2

Para EXT2, el programa empieza leyendo el superbloque, que está a partir del byte 1024 de la imagen.

Después se usan los descriptores de grupo y la tabla de inodos para poder encontrar los directorios y archivos. Para acceder a un inodo, primero se calcula a qué grupo pertenece y cuál es su posición dentro de ese grupo. Con esos datos se puede calcular dónde está ese inodo dentro de la tabla de inodos.

El recorrido del árbol empieza desde el inodo raíz, que en EXT2 es el inodo 2. A partir de ahí se leen las entradas de cada directorio y, si una entrada también es un directorio, se entra dentro de él de forma recursiva.

También se tienen en cuenta los bloques directos e indirectos del inodo, para que el recorrido no se quede solo en los 12 bloques directos.

### 4.2 FAT16

Para FAT16, el programa empieza leyendo el boot sector, ya que de ahí se sacan los datos principales del sistema de ficheros.

Con esa información se calcula dónde empieza la zona reservada, dónde están las FATs, dónde se encuentra el directorio raíz y dónde empieza la zona de datos.

El directorio raíz se lee directamente desde su posición dentro de la imagen. En cambio, para recorrer subdirectorios se usa el cluster inicial del directorio y se va siguiendo la cadena de clusters consultando la FAT hasta llegar al final.

Para mostrar los nombres de archivos y carpetas se usa el formato corto 8.3 de FAT16. Las entradas LFN se ignoran porque en este proyecto no era necesario recuperar los nombres largos.

## 5. Control de errores

El programa controla errores básicos como:

- número incorrecto de argumentos,
- imagen que no se puede abrir,
- sistema de ficheros no soportado,
- error al leer estructuras del sistema de ficheros,
- archivo no encontrado en --cat,
- intentar hacer cat de un directorio,
- clusters inválidos o final de cadena en FAT16.

## 6. Ejemplos de pruebas

Para compilar desde cero:

    make clean`
    make

Probar información en EXT2:

    ./fsutils --info images/studentext100MB

Probar información en FAT16:

    ./fsutils --info images/studentfat100MB

Probar árbol en EXT2:

    ./fsutils --tree images/studentext100MB

Probar árbol en FAT16:

    ./fsutils --tree images/studentfat100MB

Probar --cat en FAT16:

./fsutils --cat images/DEVINfat COMPUS/EXTRA/TODOLIST.TXT

También se puede probar en minúsculas:

./fsutils --cat images/DEVINfat compus/extra/todolist.txt
