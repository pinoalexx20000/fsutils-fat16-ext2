#ifndef FS_H
#define FS_H

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>

#define FS_OK 0
#define FS_ERROR 1

#endif